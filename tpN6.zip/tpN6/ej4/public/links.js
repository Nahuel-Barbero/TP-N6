function crearEnlaces() {
    const contenedor = document.getElementById('contenedor-enlaces');
    contenedor.innerHTML = ''; // Limpiar antes

    const enlaces = [
        { id: 'link1', nombre: 'Google', href: 'https://www.google.com' },
        { id: 'link2', nombre: 'Instagram', href: 'https://www.instagram.com' },
        { id: 'link3', nombre: 'WhatsApp', href: 'https://www.whatsapp.com' },
        { id: 'link4', nombre: 'Facebook', href: 'https://www.facebook.com' },
        { id: 'link5', nombre: 'YouTube', href: 'https://www.youtube.com' }
    ];

    enlaces.forEach((e, i) => {
        const enlace = document.createElement('a');
        enlace.id = e.id;
        enlace.href = e.href;
        enlace.target = '_blank';
        enlace.textContent = `Ir a ${e.nombre}`;
        contenedor.appendChild(enlace);
    });

    logCambio("Se crearon 5 enlaces con distintas plataformas.");
}

function modificarAtributos() {
    const nuevosEnlaces = [
        { id: 'link1', nuevoHref: 'https://www.netflix.com/' },
        { id: 'link2', nuevoHref: 'https://www.tiktok.com' },
        { id: 'link3', nuevoHref: 'https://web.telegram.org' },
        { id: 'link4', nuevoHref: 'https://www.linkedin.com' },
        { id: 'link5', nuevoHref: 'https://classroom.google.com/' }
    ];

    nuevosEnlaces.forEach((e) => {
        const enlace = document.getElementById(e.id);
        if (enlace) {
            const anterior = enlace.href;
            enlace.href = e.nuevoHref;
            enlace.textContent = `Enlace modificado a ${e.nuevoHref}`;
            logCambio(`${e.id}: href cambiado de ${anterior} a ${e.nuevoHref}`);
        }
    });
}

function logCambio(texto) {
    const log = document.getElementById('log');
    const item = document.createElement('li');
    item.textContent = texto;
    log.appendChild(item);
}
