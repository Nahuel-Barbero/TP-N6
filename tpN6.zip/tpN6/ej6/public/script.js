const form = document.getElementById('registration-form');
const formDataDiv = document.getElementById('form-data');

form.addEventListener('submit', async (event) => {
  event.preventDefault();

  const formData = new FormData(form);

  const response = await fetch('/submit', {
    method: 'POST',
    body: new URLSearchParams(formData),
  });

  const data = await response.json();

  formDataDiv.innerHTML = `
    <h2>Datos Enviados:</h2>
    <p><strong>Nombre:</strong> ${data.name}</p>
    <p><strong>Género:</strong> ${data.gender}</p>
    <p><strong>Correo Electrónico:</strong> ${data.email}</p>
    <p><strong>Edad:</strong> ${data.age}</p>
    <p><strong>País:</strong> ${data.country}</p>
    <p><strong>Suscripción al boletín:</strong> ${data.newsletter ? 'Sí' : 'No'}</p>
  `;
});
