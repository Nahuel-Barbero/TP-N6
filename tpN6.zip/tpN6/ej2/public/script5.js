document.getElementById('boton-dobleclick').addEventListener('dblclick', () => {
    alert('¡Doble click detectado!');
});
