function agregarH1() {
    const h1 = document.getElementById('titulo-principal');
    h1.textContent = 'Hola DOM';
}

function cambiarTextoH1() {
    const h1 = document.getElementById('titulo-principal');
    if (h1.textContent) {
        h1.textContent = 'Chau DOM';
    } else {
        alert('Primero debes agregar el H1.');
    }
}

function cambiarColorH1() {
    const h1 = document.getElementById('titulo-principal');
    if (h1.textContent) {
        h1.style.color = 'blue';
    } else {
        alert('Primero debes agregar el H1.');
    }
}

function agregarImagen() {
    const contenedor = document.getElementById('contenedor-imagen');
    if (!document.getElementById('imagen-dinamica')) {
        const img = document.createElement('img');
        img.id = 'imagen-dinamica';
        img.src = 'imagenes/paisaje.jpg';
        img.alt = 'Imagen de prueba';
        contenedor.appendChild(img);
    } else {
        alert('Ya existe una imagen.');
    }
}

function cambiarImagen() {
    const img = document.getElementById('imagen-dinamica');
    if (img) {
        img.src = 'imagenes/paisaje2.jpg';
    } else {
        alert('Primero debes agregar una imagen.');
    }
}

function cambiarTamanoImagen() {
    const img = document.getElementById('imagen-dinamica');
    if (img) {
        img.style.width = '300px';
        img.style.height = '150px';
    } else {
        alert('Primero debes agregar una imagen.');
    }
}
