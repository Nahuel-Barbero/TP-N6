document.addEventListener('DOMContentLoaded', () => {
    const boton = document.getElementById('boton-contar');
    const contenedor = document.getElementById('mi-contenedor');
    const resultado = document.getElementById('resultado');

    boton.addEventListener('click', () => {
        const hijos = contenedor.children.length;
        resultado.textContent = `El contenedor tiene ${hijos} hijo(s).`;
    });
});
